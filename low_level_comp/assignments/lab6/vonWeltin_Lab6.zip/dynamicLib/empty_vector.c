#include </home/evavw/classes/low_level_comp/assignments/lab6/staticLib/array.h>

Vector empty_vector(){
  Vector vec;
  vec.vector = NULL;
  vec.count = 0;
  vec.length = 0;

  return vec;
}
